require 'sinatra'
require 'sinatra/reloader'
require 'tilt/erubis'

configure do
  enable :sessions
  set :session_secret, 'secret'
end

before do
  session[:payment] ||= {}
  session[:payments] ||= []
end

helpers do
  def format_card(card_num)
    array = card_num.chars.map.with_index do |num, idx|
      idx < 12 ? '*' : num
    end
    array.insert(4, '-')
    array.insert(9, '-')
    array.insert(14, '-')
    array.join('')
  end
end

def missing_values?(*values)
  values.any? { |val| val.empty? }
end

def missing_values(first_name, last_name, card_num, expiration, ccv)
  result = []
  first_name.empty? ? result << 'First Name' : nil
  last_name.empty? ? result << 'Last Name' : nil
  card_num.empty? ? result << 'Card Number' : nil
  expiration.empty? ? result << 'Expiration Date' : nil
  ccv.empty? ? result << 'CCV' : nil
  result
end

def valid_card?(card)
  !(card.length == 16)
end

def check_values(first_name, last_name, card_num, expiration, ccv)
  if missing_values?(first_name, last_name, card_num, expiration, ccv)
    missing = missing_values(first_name, last_name, card_num, expiration, ccv)
    "Please enter missing #{missing.join(', ')}"
  elsif valid_card?(card_num)
    'Card Number must have 16 characters'
  end
end

get '/' do
  session.delete :payment
  erb :create_payment
end

post '/payments/create' do
  @first_name = params[:first_name]
  @last_name = params[:last_name]
  @card_num = params[:card_num]
  @expiration = params[:expiration]
  @ccv = params[:ccv]

  error = check_values(@first_name, @last_name, @card_num, @expiration, @ccv)
  if error
    session[:error] = error
    erb :create_payment
  else
    session[:success] = 'Thank you for your payment.'
    session[:payment][:first_name] = @first_name
    session[:payment][:last_name] = @last_name
    session[:payment][:card_num] = @card_num
    session[:payment][:expiration] = @expiration
    session[:payment][:ccv] = @ccv
    session[:payment][:submitted] = Time.now
    session[:payments] << session[:payment]
    redirect '/payed'
  end
end

get '/payed' do
  redirect '/' unless session[:payment]
  erb :payed
end

